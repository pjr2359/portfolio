// Main JavaScript for Portfolio Interactive Elements

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all interactive elements
    initNavigation();
    initProjectEmbeds();
    initRowingAnalytics();
    initGreekConjugator();
    initNLPTaskScheduler();
});

// Navigation functionality
function initNavigation() {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    if (hamburger) {
        hamburger.addEventListener('click', function() {
            navLinks.classList.toggle('open');
            hamburger.classList.toggle('active');
        });
    }
}

// Project embed functionality
function initProjectEmbeds() {
    // Tab switching functionality
    const tabs = document.querySelectorAll('.embed-tab');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Get the parent embed container
            const embedContainer = this.closest('.project-embed');
            
            // Remove active class from all tabs in this container
            embedContainer.querySelectorAll('.embed-tab').forEach(t => {
                t.classList.remove('active');
            });
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Get target panel
            const targetPanel = this.getAttribute('data-target');
            
            // Hide all panels in this container
            embedContainer.querySelectorAll('.embed-panel').forEach(panel => {
                panel.classList.remove('active');
            });
            
            // Show target panel
            embedContainer.querySelector(`.${targetPanel}`).classList.add('active');
        });
    });
    
    // Help button functionality
    const helpButtons = document.querySelectorAll('.embed-control-btn');
    
    helpButtons.forEach(button => {
        button.addEventListener('click', function() {
            const embedContainer = this.closest('.project-embed');
            const infoTab = embedContainer.querySelector('.embed-tab:not(.active)');
            
            if (infoTab) {
                infoTab.click();
            }
        });
    });
    
    // Project link functionality to show embeds
    const projectLinks = document.querySelectorAll('a[href^="#"][href$="-embed"]');
    
    projectLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetEmbed = document.querySelector(targetId);
            
            if (targetEmbed) {
                // Show the embed
                targetEmbed.style.display = 'block';
                
                // Scroll to it
                targetEmbed.scrollIntoView({ behavior: 'smooth' });
                
                // Update URL hash
                history.pushState(null, null, targetId);
            }
        });
    });
    
    // Handle direct URL access with hash
    if (window.location.hash && window.location.hash.endsWith('-embed')) {
        const targetEmbed = document.querySelector(window.location.hash);
        if (targetEmbed) {
            targetEmbed.style.display = 'block';
            setTimeout(() => {
                targetEmbed.scrollIntoView({ behavior: 'smooth' });
            }, 500);
        }
    }
}

// Rowing Analytics functionality
function initRowingAnalytics() {
    // Sample data for demonstration
    const rowingData = {
        rowers: [
            { name: "Alex Smith", avgPercentGMS: 92.5, races: 15 },
            { name: "Jordan Lee", avgPercentGMS: 94.8, races: 12 },
            { name: "Taylor Johnson", avgPercentGMS: 91.2, races: 14 },
            { name: "Casey Williams", avgPercentGMS: 93.7, races: 13 },
            { name: "Morgan Brown", avgPercentGMS: 90.5, races: 11 }
        ],
        races: [
            { date: "2024-03-15", location: "Boston River", distance: 2000 },
            { date: "2024-02-28", location: "Lake Washington", distance: 5000 },
            { date: "2024-02-10", location: "Charles River", distance: 2000 },
            { date: "2024-01-20", location: "Hudson River", distance: 5000 }
        ]
    };
    
    // Initialize chart if element exists
    const chartCanvas = document.getElementById('rowing-chart');
    if (chartCanvas) {
        const ctx = chartCanvas.getContext('2d');
        
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: rowingData.rowers.map(r => r.name),
                datasets: [{
                    label: 'Average % of Gold Medal Standard',
                    data: rowingData.rowers.map(r => r.avgPercentGMS),
                    backgroundColor: 'rgba(0, 159, 253, 0.7)',
                    borderColor: 'rgba(0, 159, 253, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 85,
                        max: 100
                    }
                }
            }
        });
    }
    
    // Populate rower select dropdown
    const rowerSelect = document.getElementById('rowing-rower-select');
    if (rowerSelect) {
        // Clear existing options
        rowerSelect.innerHTML = '<option value="">All Rowers</option>';
        
        // Add rower options
        rowingData.rowers.forEach(rower => {
            const option = document.createElement('option');
            option.value = rower.name;
            option.textContent = rower.name;
            rowerSelect.appendChild(option);
        });
    }
    
    // Populate race select dropdown
    const raceSelect = document.getElementById('rowing-race-select');
    if (raceSelect) {
        // Clear existing options
        raceSelect.innerHTML = '<option value="">All Races</option>';
        
        // Add race options
        rowingData.races.forEach(race => {
            const option = document.createElement('option');
            option.value = race.date;
            option.textContent = `${race.date} - ${race.location}`;
            raceSelect.appendChild(option);
        });
    }
    
    // Update table with rower data
    const tableBody = document.getElementById('rowing-table-body');
    if (tableBody) {
        // Clear existing rows
        tableBody.innerHTML = '';
        
        // Add rower rows
        rowingData.rowers.forEach(rower => {
            const row = document.createElement('tr');
            
            const nameCell = document.createElement('td');
            nameCell.textContent = rower.name;
            
            const percentCell = document.createElement('td');
            percentCell.textContent = `${rower.avgPercentGMS}%`;
            
            const racesCell = document.createElement('td');
            racesCell.textContent = rower.races;
            
            row.appendChild(nameCell);
            row.appendChild(percentCell);
            row.appendChild(racesCell);
            
            tableBody.appendChild(row);
        });
    }
    
    // Add event listeners for filtering
    if (rowerSelect && raceSelect) {
        rowerSelect.addEventListener('change', filterRowingData);
        raceSelect.addEventListener('change', filterRowingData);
    }
}

// Filter rowing data based on selections
function filterRowingData() {
    const rowerSelect = document.getElementById('rowing-rower-select');
    const raceSelect = document.getElementById('rowing-race-select');
    
    if (rowerSelect && raceSelect) {
        const selectedRower = rowerSelect.value;
        const selectedRace = raceSelect.value;
        
        console.log(`Filtering data - Rower: ${selectedRower || 'All'}, Race: ${selectedRace || 'All'}`);
        
        // In a real implementation, this would update the chart and table
        // For this demo, we'll just log the selections
    }
}

// Greek Conjugator functionality
function initGreekConjugator() {
    // Sample data for demonstration
    const greekVerbs = [
        { name: "λύω", meaning: "to loosen", stem: "λυ" },
        { name: "γράφω", meaning: "to write", stem: "γραφ" },
        { name: "παιδεύω", meaning: "to educate", stem: "παιδευ" },
        { name: "τιμάω", meaning: "to honor", stem: "τιμα" }
    ];

    const tenses = ["Present", "Imperfect", "Future", "Aorist", "Perfect", "Pluperfect"];
    const voices = ["Active", "Middle", "Passive"];
    const moods = ["Indicative", "Subjunctive", "Optative", "Imperative"];
    
    // Populate verb select dropdown
    const verbSelect = document.getElementById('greek-verb-select');
    if (verbSelect) {
        // Clear existing options
        verbSelect.innerHTML = '';
        
        // Add verb options
        greekVerbs.forEach(verb => {
            const option = document.createElement('option');
            option.value = verb.name;
            option.textContent = `${verb.name} (${verb.meaning})`;
            verbSelect.appendChild(option);
        });
    }
    
    // Populate tense select dropdown
    const tenseSelect = document.getElementById('greek-tense-select');
    if (tenseSelect) {
        // Clear existing options
        tenseSelect.innerHTML = '';
        
        // Add tense options
        tenses.forEach(tense => {
            const option = document.createElement('option');
            option.value = tense.toLowerCase();
            option.textContent = tense;
            tenseSelect.appendChild(option);
        });
    }
    
    // Populate voice select dropdown
    const voiceSelect = document.getElementById('greek-voice-select');
    if (voiceSelect) {
        // Clear existing options
        voiceSelect.innerHTML = '';
        
        // Add voice options
        voices.forEach(voice => {
            const option = document.createElement('option');
            option.value = voice.toLowerCase();
            option.textContent = voice;
            voiceSelect.appendChild(option);
        });
    }
    
    // Populate mood select dropdown
    const moodSelect = document.getElementById('greek-mood-select');
    if (moodSelect) {
        // Clear existing options
        moodSelect.innerHTML = '';
        
        // Add mood options
        moods.forEach(mood => {
            const option = document.createElement('option');
            option.value = mood.toLowerCase();
            option.textContent = mood;
            moodSelect.appendChild(option);
        });
    }
    
    // Generate initial conjugation
    generateConjugation();
    
    // Add event listeners for form changes
    if (verbSelect && tenseSelect && voiceSelect && moodSelect) {
        verbSelect.addEventListener('change', generateConjugation);
        tenseSelect.addEventListener('change', generateConjugation);
        voiceSelect.addEventListener('change', generateConjugation);
        moodSelect.addEventListener('change', generateConjugation);
    }
    
    // Function to generate conjugation
    function generateConjugation() {
        const verbSelect = document.getElementById('greek-verb-select');
        const tenseSelect = document.getElementById('greek-tense-select');
        const voiceSelect = document.getElementById('greek-voice-select');
        const moodSelect = document.getElementById('greek-mood-select');
        const tableBody = document.getElementById('greek-table-body');
        const infoElement = document.getElementById('greek-conjugation-info');
        
        if (!verbSelect || !tenseSelect || !voiceSelect || !moodSelect || !tableBody || !infoElement) {
            return;
        }
        
        const verb = verbSelect.value;
        const tense = tenseSelect.value;
        const voice = voiceSelect.value;
        const mood = moodSelect.value;
        
        const selectedVerb = greekVerbs.find(v => v.name === verb) || greekVerbs[0];
        const stem = selectedVerb.stem;
        
        // Simple algorithm to generate sample conjugations
        // This is just for demonstration purposes
        const endings = {
            present: {
                active: {
                    indicative: ['ω', 'εις', 'ει', 'ομεν', 'ετε', 'ουσι(ν)'],
                    subjunctive: ['ω', 'ῃς', 'ῃ', 'ωμεν', 'ητε', 'ωσι(ν)'],
                    optative: ['οιμι', 'οις', 'οι', 'οιμεν', 'οιτε', 'οιεν'],
                    imperative: ['ε', 'ετω', '', 'ετε', 'οντων', '']
                },
                middle: {
                    indicative: ['ομαι', 'ῃ', 'εται', 'ομεθα', 'εσθε', 'ονται'],
                    subjunctive: ['ωμαι', 'ῃ', 'ηται', 'ωμεθα', 'ησθε', 'ωνται'],
                    optative: ['οιμην', 'οιο', 'οιτο', 'οιμεθα', 'οισθε', 'οιντο'],
                    imperative: ['ου', 'εσθω', '', 'εσθε', 'εσθων', '']
                },
                passive: {
                    indicative: ['ομαι', 'ῃ', 'εται', 'ομεθα', 'εσθε', 'ονται'],
                    subjunctive: ['ωμαι', 'ῃ', 'ηται', 'ωμεθα', 'ησθε', 'ωνται'],
                    optative: ['οιμην', 'οιο', 'οιτο', 'οιμεθα', 'οισθε', 'οιντο'],
                    imperative: ['ου', 'εσθω', '', 'εσθε', 'εσθων', '']
                }
            },
            future: {
                active: {
                    indicative: ['σω', 'σεις', 'σει', 'σομεν', 'σετε', 'σουσι(ν)'],
                    optative: ['σοιμι', 'σοις', 'σοι', 'σοιμεν', 'σοιτε', 'σοιεν']
                },
                middle: {
                    indicative: ['σομαι', 'σῃ', 'σεται', 'σομεθα', 'σεσθε', 'σονται'],
                    optative: ['σοιμην', 'σοιο', 'σοιτο', 'σοιμεθα', 'σοισθε', 'σοιντο']
                },
                passive: {
                    indicative: ['θησομαι', 'θησῃ', 'θησεται', 'θησομεθα', 'θησεσθε', 'θησονται'],
                    optative: ['θησοιμην', 'θησοιο', 'θησοιτο', 'θησοιμεθα', 'θησοισθε', 'θησοιντο']
                }
            }
        };
        
        // Default endings if specific combination not found
        const defaultEndings = ['ω', 'εις', 'ει', 'ομεν', 'ετε', 'ουσι(ν)'];
        
        // Get appropriate endings or use defaults
        const currentEndings = endings[tense]?.[voice]?.[mood] || defaultEndings;
        
        // Generate conjugated forms
        const conjugated = currentEndings.map(ending => stem + ending);
        
        // Update the table
        tableBody.innerHTML = '';
        
        const persons = ['1st Person Singular', '2nd Person Singular', '3rd Person Singular', 
                        '1st Person Plural', '2nd Person Plural', '3rd Person Plural'];
        
        persons.forEach((person, index) => {
            const row = document.createElement('tr');
            
            const personCell = document.createElement('td');
            personCell.textContent = person;
            
            const formCell = document.createElement('td');
            formCell.textContent = conjugated[index];
            
            row.appendChild(personCell);
            row.appendChild(formCell);
            
            tableBody.appendChild(row);
        });
        
        // Update conjugation info
        infoElement.textContent = `${selectedVerb.name} - ${tense} ${voice} ${mood}`;
    }
}

// NLP Task Scheduler functionality
function initNLPTaskScheduler() {
    // Sample tasks for demonstration
    const sampleTasks = [
        { 
            text: "Meeting with team tomorrow at 2pm", 
            parsed: {
                type: "Meeting",
                date: "2025-04-07",
                time: "14:00",
                duration: "1 hour"
            }
        },
        { 
            text: "Submit project proposal by Friday", 
            parsed: {
                type: "Deadline",
                date: "2025-04-11",
                time: "23:59",
                priority: "High"
            }
        },
        { 
            text: "Call John about the presentation next Monday", 
            parsed: {
                type: "Call",
                date: "2025-04-14",
                time: "09:00",
                contact: "John"
            }
        }
    ];
    
    // Display sample tasks
    displaySampleTasks();
    
    // Set up form handling
    const taskForm = document.getElementById('nlp-task-form');
    if (taskForm) {
        taskForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const taskInput = document.getElementById('nlp-task-input');
            if (taskInput && taskInput.value.trim() !== '') {
                parseTask(taskInput.value.trim());
                taskInput.value = '';
            }
        });
    }
    
    // Function to display sample tasks
    function displaySampleTasks() {
        const taskResults = document.getElementById('nlp-task-results');
        if (!taskResults) return;
        
        // Clear existing tasks
        taskResults.innerHTML = '';
        
        // Display sample tasks
        sampleTasks.forEach(task => {
            displayTask(task);
        });
    }
    
    // Function to parse task using simple rules (simulation)
    function parseTask(text) {
        // This is a simplified simulation of NLP parsing
        // In a real app, this would use a proper NLP library
        
        let taskType = "Task";
        let date = "2025-04-07"; // Default to tomorrow
        let time = "";
        let priority = "Normal";
        
        // Very simple pattern matching
        if (text.toLowerCase().includes("meeting")) {
            taskType = "Meeting";
        } else if (text.toLowerCase().includes("call")) {
            taskType = "Call";
        } else if (text.toLowerCase().includes("deadline") || text.toLowerCase().includes("submit")) {
            taskType = "Deadline";
            priority = "High";
        }
        
        // Simple date extraction
        if (text.toLowerCase().includes("tomorrow")) {
            date = "2025-04-07"; // Assuming today is April 6, 2025
        } else if (text.toLowerCase().includes("friday")) {
            date = "2025-04-11";
        } else if (text.toLowerCase().includes("monday")) {
            date = "2025-04-14";
        }
        
        // Simple time extraction
        if (text.includes("2pm") || text.includes("2 pm")) {
            time = "14:00";
        } else if (text.includes("9am") || text.includes("9 am")) {
            time = "09:00";
        }
        
        // Create parsed task object
        const parsedTask = {
            text: text,
            parsed: {
                type: taskType,
                date: date,
                time: time || "00:00",
                priority: priority
            }
        };
        
        // Display the parsed task
        displayTask(parsedTask);
    }
    
    // Function to display task in the results area
    function displayTask(task) {
        const taskResults = document.getElementById('nlp-task-results');
        if (!taskResults) return;
        
        const taskCard = document.createElement('div');
        taskCard.className = 'task-card';
        
        const taskTitle = document.createElement('div');
        taskTitle.className = 'task-title';
        taskTitle.textContent = task.text;
        
        const taskDate = document.createElement('div');
        taskDate.className = 'task-date';
        taskDate.textContent = `${task.parsed.date} ${task.parsed.time}`;
        
        const taskDetails = document.createElement('div');
        taskDetails.className = 'task-details';
        
        // Add task type
        const typeDetail = document.createElement('span');
        typeDetail.className = 'task-detail';
        typeDetail.textContent = `Type: ${task.parsed.type}`;
        taskDetails.appendChild(typeDetail);
        
        // Add priority if available
        if (task.parsed.priority) {
            const priorityDetail = document.createElement('span');
            priorityDetail.className = 'task-detail';
            priorityDetail.textContent = `Priority: ${task.parsed.priority}`;
            taskDetails.appendChild(priorityDetail);
        }
        
        // Add contact if available
        if (task.parsed.contact) {
            const contactDetail = document.createElement('span');
            contactDetail.className = 'task-detail';
            contactDetail.textContent = `Contact: ${task.parsed.contact}`;
            taskDetails.appendChild(contactDetail);
        }
        
        // Add duration if available
        if (task.parsed.duration) {
            const durationDetail = document.createElement('span');
            durationDetail.className = 'task-detail';
            durationDetail.textContent = `Duration: ${task.parsed.duration}`;
            taskDetails.appendChild(durationDetail);
        }
        
        // Assemble the task card
        taskCard.appendChild(taskTitle);
        taskCard.appendChild(taskDate);
        taskCard.appendChild(taskDetails);
        
        // Add to results
        taskResults.prepend(taskCard);
    }
}
